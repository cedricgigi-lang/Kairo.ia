// Kairo.IA — l'IA qui répond à tout et qui écrit des chansons
// Serveur : Cloudflare Worker « kairoia » (Gemini, GPT-OSS, Qwen, Llama)
import React, { useEffect, useRef, useState } from 'react';
import {
  View, Text, TextInput, TouchableOpacity, FlatList, KeyboardAvoidingView,
  Platform, StatusBar, Share, Modal, ScrollView, Alert, Animated, StyleSheet,
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { SafeAreaProvider, useSafeAreaInsets } from 'react-native-safe-area-context';

// === CONFIG ===
const SERVEUR = 'https://kairoia.ursjeixitx.workers.dev';
const CONVS_KEY = 'kairo.convs';
const PREFS_KEY = 'kairo.prefs';
const DELAI_MS = 60000;

const IAS = [
  { id: 'gemini', nom: 'Gemini', emoji: '✨', couleur: '#4F8CFF' },
  { id: 'gpt', nom: 'GPT-OSS', emoji: '🧠', couleur: '#10B981' },
  { id: 'qwen', nom: 'Qwen', emoji: '🐉', couleur: '#F59E0B' },
  { id: 'llama', nom: 'Llama', emoji: '🦙', couleur: '#EC4899' },
];
const iaDe = (id) => IAS.find((i) => i.id === id) || IAS[0];

const SUGGESTIONS = {
  chat: [
    '💡 Donne-moi 5 idées de business à lancer avec peu d\'argent',
    '📚 Explique-moi la photosynthèse simplement',
    '✍️ Écris un message pour souhaiter bon anniversaire à mon ami',
    '🍲 Une recette facile avec du riz et des haricots',
  ],
  chanson: [
    '❤️ Une chanson d\'amour douce, style rumba',
    '🔥 Un rap motivant sur la réussite',
    '🎂 Une chanson pour l\'anniversaire de ma mère',
    '🙏 Un chant de louange joyeux',
  ],
};

const C = {
  fond: '#0D0E1A', carte: '#171A2C', carte2: '#20243A', bord: '#2A2F4A',
  texte: '#ECEEFF', gris: '#8C92B5', accent: '#7C5CFF', accent2: '#22D3EE',
  erreur: '#FF5C7A',
};

const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 7);

function nouvelleConv(modele, mode) {
  return { id: uid(), titre: 'Nouvelle discussion', modele, mode, messages: [], maj: Date.now() };
}

function messageErreur(e) {
  const t = String(e || '');
  if (/abort/i.test(t)) return 'La réponse prend trop de temps ⏳ Réessaie dans un instant.';
  if (/network|failed to fetch|request failed/i.test(t)) return 'Pas de connexion internet 📶 Vérifie ton réseau et réessaie.';
  if (/429|quota|limit|exhausted|4006|allocation/i.test(t))
    return 'Cette IA a atteint sa limite pour aujourd\'hui 😅 Choisis une autre IA en haut.';
  return 'Oups, une erreur est survenue : ' + t;
}

// === TEXTE ENRICHI (titres, gras, listes, code) ===
function Inline({ texte, style }) {
  const morceaux = String(texte).split(/(\*\*[^*]+\*\*)/g);
  return (
    <Text style={style}>
      {morceaux.map((m, i) =>
        m.startsWith('**') && m.endsWith('**') && m.length > 4
          ? <Text key={i} style={{ fontWeight: 'bold' }}>{m.slice(2, -2)}</Text>
          : <Text key={i}>{m}</Text>
      )}
    </Text>
  );
}

function TexteRiche({ texte, couleur }) {
  const blocs = [];
  const parties = String(texte).split('```');
  parties.forEach((p, i) => {
    if (i % 2 === 1) {
      const code = p.replace(/^[a-zA-Z]*\n/, '');
      blocs.push(
        <View key={'c' + i} style={s.code}>
          <Text style={s.codeTexte} selectable>{code.trim()}</Text>
        </View>
      );
      return;
    }
    p.split('\n').forEach((ligne, j) => {
      const k = i + '-' + j;
      if (!ligne.trim()) { blocs.push(<View key={k} style={{ height: 6 }} />); return; }
      const titre = ligne.match(/^#{1,4}\s+(.*)/);
      if (titre) {
        blocs.push(<Inline key={k} texte={titre[1]} style={[s.titreMd, { color: couleur }]} />);
        return;
      }
      const puce = ligne.match(/^\s*[-*•]\s+(.*)/);
      if (puce) {
        blocs.push(
          <View key={k} style={s.puceLigne}>
            <Text style={[s.msgTexte, { color: couleur }]}>•  </Text>
            <Inline texte={puce[1]} style={[s.msgTexte, { color: couleur, flex: 1 }]} />
          </View>
        );
        return;
      }
      blocs.push(<Inline key={k} texte={ligne} style={[s.msgTexte, { color: couleur }]} />);
    });
  });
  return <View>{blocs}</View>;
}

// === INDICATEUR « KAIRO RÉFLÉCHIT » ===
function Points({ couleur }) {
  const a = useRef([0, 1, 2].map(() => new Animated.Value(0.3))).current;
  useEffect(() => {
    const anims = a.map((v, i) =>
      Animated.loop(Animated.sequence([
        Animated.delay(i * 160),
        Animated.timing(v, { toValue: 1, duration: 320, useNativeDriver: true }),
        Animated.timing(v, { toValue: 0.3, duration: 320, useNativeDriver: true }),
        Animated.delay((2 - i) * 160),
      ]))
    );
    anims.forEach((x) => x.start());
    return () => anims.forEach((x) => x.stop());
  }, []);
  return (
    <View style={{ flexDirection: 'row', alignItems: 'center' }}>
      {a.map((v, i) => (
        <Animated.View key={i} style={[s.point, { backgroundColor: couleur, opacity: v }]} />
      ))}
    </View>
  );
}

// === ÉCRAN PRINCIPAL ===
function Kairo() {
  const ins = useSafeAreaInsets();
  const [convs, setConvs] = useState([]);
  const [actuelle, setActuelle] = useState(null);
  const [modele, setModele] = useState('gemini');
  const [mode, setMode] = useState('chat');
  const [saisie, setSaisie] = useState('');
  const [attente, setAttente] = useState(false);
  const [historique, setHistorique] = useState(false);
  const [pret, setPret] = useState(false);
  const liste = useRef(null);

  // Chargement
  useEffect(() => {
    (async () => {
      try {
        const p = JSON.parse((await AsyncStorage.getItem(PREFS_KEY)) || '{}');
        const m = p.modele && IAS.some((i) => i.id === p.modele) ? p.modele : 'gemini';
        const md = p.mode === 'chanson' ? 'chanson' : 'chat';
        setModele(m); setMode(md);
        const cs = JSON.parse((await AsyncStorage.getItem(CONVS_KEY)) || '[]');
        setConvs(Array.isArray(cs) ? cs : []);
        setActuelle(nouvelleConv(m, md));
      } catch (e) {
        setActuelle(nouvelleConv('gemini', 'chat'));
      }
      setPret(true);
    })();
  }, []);

  // Sauvegarde
  useEffect(() => {
    if (!pret) return;
    AsyncStorage.setItem(CONVS_KEY, JSON.stringify(convs.slice(0, 50))).catch(() => {});
  }, [convs, pret]);
  useEffect(() => {
    if (!pret) return;
    AsyncStorage.setItem(PREFS_KEY, JSON.stringify({ modele, mode })).catch(() => {});
  }, [modele, mode, pret]);

  const enregistrer = (conv) => {
    setActuelle(conv);
    if (!conv.messages.length) return;
    setConvs((cs) => [conv, ...cs.filter((c) => c.id !== conv.id)]);
  };

  const defiler = () => setTimeout(() => liste.current && liste.current.scrollToEnd({ animated: true }), 80);

  async function demander(conv, iaId) {
    setAttente(true);
    defiler();
    const historiqueMsgs = conv.messages
      .filter((m) => !m.erreur)
      .map((m) => ({ role: m.role, content: m.content }));
    const ctrl = new AbortController();
    const minuteur = setTimeout(() => ctrl.abort(), DELAI_MS);
    let suivant;
    try {
      const res = await fetch(SERVEUR, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ model: iaId, mode, messages: historiqueMsgs }),
        signal: ctrl.signal,
      });
      const d = await res.json().catch(() => ({}));
      if (!res.ok || !d.reponse) throw new Error(d.erreur || 'Erreur ' + res.status);
      suivant = { id: uid(), role: 'assistant', content: d.reponse, modele: iaId, mode };
    } catch (e) {
      const brut = e && e.name === 'AbortError' ? 'abort' : (e && e.message) || e;
      suivant = { id: uid(), role: 'assistant', content: messageErreur(brut), modele: iaId, erreur: true };
    } finally {
      clearTimeout(minuteur);
    }
    const maj = { ...conv, messages: [...conv.messages, suivant], maj: Date.now() };
    enregistrer(maj);
    setAttente(false);
    defiler();
  }

  function envoyer(texteForce) {
    const texte = (texteForce != null ? texteForce : saisie).trim();
    if (!texte || attente || !actuelle) return;
    setSaisie('');
    const msg = { id: uid(), role: 'user', content: texte };
    const titre = actuelle.messages.length ? actuelle.titre : texte.replace(/^\W+\s*/, '').slice(0, 42);
    const conv = { ...actuelle, titre, modele, mode, messages: [...actuelle.messages, msg], maj: Date.now() };
    enregistrer(conv);
    demander(conv, modele);
  }

  function reessayer(iaId) {
    if (attente || !actuelle) return;
    const msgs = [...actuelle.messages];
    while (msgs.length && msgs[msgs.length - 1].erreur) msgs.pop();
    if (!msgs.length || msgs[msgs.length - 1].role !== 'user') return;
    if (iaId) setModele(iaId);
    const conv = { ...actuelle, messages: msgs };
    setActuelle(conv);
    demander(conv, iaId || modele);
  }

  function nouvelle() {
    if (attente) return;
    setActuelle(nouvelleConv(modele, mode));
    setSaisie('');
  }

  function ouvrir(c) {
    setActuelle(c);
    if (c.modele) setModele(c.modele);
    if (c.mode) setMode(c.mode);
    setHistorique(false);
    defiler();
  }

  function supprimer(c) {
    Alert.alert('Supprimer', 'Supprimer « ' + c.titre + ' » ?', [
      { text: 'Annuler', style: 'cancel' },
      {
        text: 'Supprimer', style: 'destructive', onPress: () => {
          setConvs((cs) => cs.filter((x) => x.id !== c.id));
          if (actuelle && actuelle.id === c.id) setActuelle(nouvelleConv(modele, mode));
        },
      },
    ]);
  }

  function toutEffacer() {
    Alert.alert('Tout effacer', 'Supprimer toutes les discussions ?', [
      { text: 'Annuler', style: 'cancel' },
      {
        text: 'Tout effacer', style: 'destructive', onPress: () => {
          setConvs([]); setActuelle(nouvelleConv(modele, mode)); setHistorique(false);
        },
      },
    ]);
  }

  const partager = (texte) => Share.share({ message: texte + '\n\n— créé avec Kairo.IA' }).catch(() => {});

  if (!pret || !actuelle) {
    return <View style={[s.ecran, { justifyContent: 'center', alignItems: 'center' }]}><Logo taille={72} /></View>;
  }

  const ia = iaDe(modele);
  const vide = actuelle.messages.length === 0;
  const dernier = actuelle.messages[actuelle.messages.length - 1];

  const rendu = ({ item }) => {
    const moi = item.role === 'user';
    const iam = iaDe(item.modele);
    const estDernier = dernier && item.id === dernier.id;
    return (
      <View style={[s.ligneMsg, moi ? { justifyContent: 'flex-end' } : null]}>
        <TouchableOpacity
          activeOpacity={0.85}
          onLongPress={() => !item.erreur && partager(item.content)}
          style={[
            s.bulle,
            moi ? s.bulleMoi : s.bulleIA,
            item.erreur ? { borderColor: C.erreur } : null,
          ]}
        >
          {!moi && (
            <Text style={[s.etiquette, { color: item.erreur ? C.erreur : iam.couleur }]}>
              {item.erreur ? '⚠️ ' : iam.emoji + ' '}{iam.nom}{item.mode === 'chanson' ? '  ·  🎵 Chanson' : ''}
            </Text>
          )}
          {moi
            ? <Text style={[s.msgTexte, { color: '#fff' }]} selectable>{item.content}</Text>
            : <TexteRiche texte={item.content} couleur={item.erreur ? '#FFD0D9' : C.texte} />}
          {!moi && !item.erreur && (
            <View style={s.actions}>
              <TouchableOpacity onPress={() => partager(item.content)} style={s.actionBtn}>
                <Text style={s.actionTexte}>{item.mode === 'chanson' ? '🎵 Partager la chanson' : '↗ Partager'}</Text>
              </TouchableOpacity>
            </View>
          )}
          {item.erreur && estDernier && !attente && (
            <View style={s.actions}>
              <TouchableOpacity onPress={() => reessayer()} style={s.actionBtn}>
                <Text style={s.actionTexte}>🔄 Réessayer</Text>
              </TouchableOpacity>
              {IAS.filter((x) => x.id !== item.modele).slice(0, 2).map((x) => (
                <TouchableOpacity key={x.id} onPress={() => reessayer(x.id)} style={s.actionBtn}>
                  <Text style={s.actionTexte}>{x.emoji} {x.nom}</Text>
                </TouchableOpacity>
              ))}
            </View>
          )}
        </TouchableOpacity>
      </View>
    );
  };

  return (
    <View style={[s.ecran, { paddingTop: ins.top }]}>
      <StatusBar barStyle="light-content" />

      {/* En-tête */}
      <View style={s.entete}>
        <TouchableOpacity onPress={() => setHistorique(true)} style={s.iconeBtn}>
          <Text style={s.icone}>☰</Text>
        </TouchableOpacity>
        <View style={{ flexDirection: 'row', alignItems: 'center' }}>
          <Logo taille={30} />
          <Text style={s.titre}>  Kairo<Text style={{ color: C.accent2 }}>.IA</Text></Text>
        </View>
        <TouchableOpacity onPress={nouvelle} style={s.iconeBtn}>
          <Text style={s.icone}>✎</Text>
        </TouchableOpacity>
      </View>

      {/* Choix de l'IA + mode */}
      <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={s.puces}>
        {IAS.map((x) => {
          const actif = x.id === modele;
          return (
            <TouchableOpacity
              key={x.id}
              onPress={() => !attente && setModele(x.id)}
              style={[s.puce, actif ? { backgroundColor: x.couleur, borderColor: x.couleur } : null]}
            >
              <Text style={[s.puceTexte, actif ? { color: '#fff' } : null]}>{x.emoji} {x.nom}</Text>
            </TouchableOpacity>
          );
        })}
      </ScrollView>
      <View style={s.modes}>
        {[['chat', '💬 Discussion'], ['chanson', '🎵 Créer une chanson']].map(([id, nom]) => (
          <TouchableOpacity
            key={id}
            onPress={() => !attente && setMode(id)}
            style={[s.modeBtn, mode === id ? s.modeActif : null]}
          >
            <Text style={[s.modeTexte, mode === id ? { color: '#fff' } : null]}>{nom}</Text>
          </TouchableOpacity>
        ))}
      </View>

      <KeyboardAvoidingView style={{ flex: 1 }} behavior="padding">
        {vide ? (
          <ScrollView contentContainerStyle={s.accueil} keyboardShouldPersistTaps="handled">
            <Logo taille={84} />
            <Text style={s.bonjour}>
              {mode === 'chanson' ? 'Quelle chanson on écrit ? 🎤' : 'Bonjour 👋 Je suis Kairo.IA'}
            </Text>
            <Text style={s.sousTitre}>
              {mode === 'chanson'
                ? 'Dis-moi le thème, le style et la langue : je t\'écris les paroles, le refrain et les accords.'
                : 'Pose-moi n\'importe quelle question. Tu discutes en ce moment avec ' + ia.emoji + ' ' + ia.nom + '.'}
            </Text>
            {SUGGESTIONS[mode].map((t) => (
              <TouchableOpacity key={t} style={s.suggestion} onPress={() => envoyer(t)}>
                <Text style={s.suggestionTexte}>{t}</Text>
              </TouchableOpacity>
            ))}
          </ScrollView>
        ) : (
          <FlatList
            ref={liste}
            data={actuelle.messages}
            keyExtractor={(m) => m.id}
            renderItem={rendu}
            contentContainerStyle={{ padding: 12, paddingBottom: 8 }}
            onContentSizeChange={defiler}
            keyboardShouldPersistTaps="handled"
            ListFooterComponent={attente ? (
              <View style={s.ligneMsg}>
                <View style={[s.bulle, s.bulleIA, { flexDirection: 'row', alignItems: 'center' }]}>
                  <Text style={[s.etiquette, { color: ia.couleur, marginBottom: 0 }]}>
                    {ia.emoji} {mode === 'chanson' ? 'Kairo compose' : 'Kairo réfléchit'}
                  </Text>
                  <Points couleur={ia.couleur} />
                </View>
              </View>
            ) : null}
          />
        )}

        {/* Zone de saisie */}
        <View style={[s.barre, { paddingBottom: Math.max(ins.bottom, 10) }]}>
          <TextInput
            style={s.champ}
            value={saisie}
            onChangeText={setSaisie}
            placeholder={mode === 'chanson' ? 'Thème, style, langue de ta chanson…' : 'Écris ton message…'}
            placeholderTextColor={C.gris}
            multiline
            maxLength={4000}
          />
          <TouchableOpacity
            onPress={() => envoyer()}
            disabled={attente || !saisie.trim()}
            style={[s.envoyer, { backgroundColor: attente || !saisie.trim() ? C.carte2 : ia.couleur }]}
          >
            <Text style={s.envoyerTexte}>{mode === 'chanson' ? '🎵' : '➤'}</Text>
          </TouchableOpacity>
        </View>
      </KeyboardAvoidingView>

      {/* Historique */}
      <Modal visible={historique} animationType="slide" transparent onRequestClose={() => setHistorique(false)}>
        <View style={s.voile}>
          <View style={[s.panneau, { paddingTop: ins.top + 12, paddingBottom: ins.bottom + 12 }]}>
            <View style={s.panneauTete}>
              <Text style={s.panneauTitre}>🕘 Discussions</Text>
              <TouchableOpacity onPress={() => setHistorique(false)} style={s.iconeBtn}>
                <Text style={s.icone}>✕</Text>
              </TouchableOpacity>
            </View>
            <TouchableOpacity style={s.nouvelleBtn} onPress={() => { nouvelle(); setHistorique(false); }}>
              <Text style={s.nouvelleTexte}>＋ Nouvelle discussion</Text>
            </TouchableOpacity>
            <FlatList
              data={convs}
              keyExtractor={(c) => c.id}
              ListEmptyComponent={<Text style={s.videTexte}>Aucune discussion pour l'instant.</Text>}
              renderItem={({ item }) => (
                <TouchableOpacity
                  style={[s.convLigne, actuelle && actuelle.id === item.id ? { borderColor: C.accent } : null]}
                  onPress={() => ouvrir(item)}
                  onLongPress={() => supprimer(item)}
                >
                  <Text style={s.convEmoji}>{item.mode === 'chanson' ? '🎵' : iaDe(item.modele).emoji}</Text>
                  <View style={{ flex: 1 }}>
                    <Text style={s.convTitre} numberOfLines={1}>{item.titre}</Text>
                    <Text style={s.convDate}>
                      {iaDe(item.modele).nom} · {new Date(item.maj).toLocaleDateString('fr-FR')}
                    </Text>
                  </View>
                  <TouchableOpacity onPress={() => supprimer(item)} style={s.iconeBtn}>
                    <Text style={{ fontSize: 16 }}>🗑</Text>
                  </TouchableOpacity>
                </TouchableOpacity>
              )}
            />
            {convs.length > 0 && (
              <TouchableOpacity onPress={toutEffacer} style={{ padding: 12, alignItems: 'center' }}>
                <Text style={{ color: C.erreur }}>Tout effacer</Text>
              </TouchableOpacity>
            )}
          </View>
          <TouchableOpacity style={{ flex: 1 }} onPress={() => setHistorique(false)} />
        </View>
      </Modal>
    </View>
  );
}

// === LOGO « K » ===
function Logo({ taille }) {
  return (
    <View style={{
      width: taille, height: taille, borderRadius: taille * 0.3, backgroundColor: C.accent,
      alignItems: 'center', justifyContent: 'center', overflow: 'hidden',
    }}>
      <View style={{
        position: 'absolute', width: taille * 0.9, height: taille * 0.9, borderRadius: taille,
        backgroundColor: C.accent2, opacity: 0.55, right: -taille * 0.35, bottom: -taille * 0.35,
      }} />
      <Text style={{ color: '#fff', fontSize: taille * 0.55, fontWeight: 'bold' }}>K</Text>
    </View>
  );
}

export default function App() {
  return (
    <SafeAreaProvider>
      <Kairo />
    </SafeAreaProvider>
  );
}

const s = StyleSheet.create({
  ecran: { flex: 1, backgroundColor: C.fond },
  entete: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: 10, paddingVertical: 8,
  },
  titre: { color: C.texte, fontSize: 22, fontWeight: 'bold' },
  iconeBtn: { padding: 8, minWidth: 40, alignItems: 'center' },
  icone: { color: C.texte, fontSize: 22 },
  puces: { paddingHorizontal: 10, gap: 8, paddingVertical: 4 },
  puce: {
    paddingHorizontal: 14, paddingVertical: 8, borderRadius: 20, borderWidth: 1,
    borderColor: C.bord, backgroundColor: C.carte,
  },
  puceTexte: { color: C.gris, fontWeight: '600' },
  modes: {
    flexDirection: 'row', marginHorizontal: 12, marginTop: 8, marginBottom: 4,
    backgroundColor: C.carte, borderRadius: 14, padding: 4,
  },
  modeBtn: { flex: 1, paddingVertical: 9, borderRadius: 10, alignItems: 'center' },
  modeActif: { backgroundColor: C.accent },
  modeTexte: { color: C.gris, fontWeight: '600' },
  accueil: { alignItems: 'center', padding: 24, paddingTop: 36 },
  bonjour: { color: C.texte, fontSize: 22, fontWeight: 'bold', marginTop: 18, textAlign: 'center' },
  sousTitre: { color: C.gris, fontSize: 15, textAlign: 'center', marginTop: 8, marginBottom: 20, lineHeight: 21 },
  suggestion: {
    alignSelf: 'stretch', backgroundColor: C.carte, borderColor: C.bord, borderWidth: 1,
    borderRadius: 14, padding: 14, marginBottom: 10,
  },
  suggestionTexte: { color: C.texte, fontSize: 15 },
  ligneMsg: { flexDirection: 'row', marginBottom: 10 },
  bulle: { maxWidth: '88%', borderRadius: 18, paddingHorizontal: 14, paddingVertical: 10, borderWidth: 1 },
  bulleMoi: { backgroundColor: C.accent, borderColor: C.accent, borderBottomRightRadius: 6 },
  bulleIA: { backgroundColor: C.carte, borderColor: C.bord, borderBottomLeftRadius: 6 },
  etiquette: { fontSize: 12, fontWeight: 'bold', marginBottom: 4 },
  msgTexte: { fontSize: 16, lineHeight: 23 },
  titreMd: { fontSize: 17, fontWeight: 'bold', marginTop: 4, marginBottom: 2 },
  puceLigne: { flexDirection: 'row', paddingLeft: 4 },
  code: { backgroundColor: '#0A0B14', borderRadius: 10, padding: 10, marginVertical: 6 },
  codeTexte: { color: '#A5F3FC', fontFamily: Platform.OS === 'ios' ? 'Menlo' : 'monospace', fontSize: 13 },
  actions: { flexDirection: 'row', flexWrap: 'wrap', gap: 6, marginTop: 8 },
  actionBtn: { backgroundColor: C.carte2, borderRadius: 12, paddingHorizontal: 10, paddingVertical: 6 },
  actionTexte: { color: C.texte, fontSize: 13 },
  point: { width: 7, height: 7, borderRadius: 4, marginHorizontal: 2 },
  barre: {
    flexDirection: 'row', alignItems: 'flex-end', paddingHorizontal: 10, paddingTop: 8,
    borderTopWidth: 1, borderTopColor: C.bord, backgroundColor: C.fond,
  },
  champ: {
    flex: 1, color: C.texte, backgroundColor: C.carte, borderRadius: 22, borderWidth: 1,
    borderColor: C.bord, paddingHorizontal: 16, paddingTop: 11, paddingBottom: 11,
    fontSize: 16, maxHeight: 140,
  },
  envoyer: {
    width: 46, height: 46, borderRadius: 23, alignItems: 'center', justifyContent: 'center', marginLeft: 8,
  },
  envoyerTexte: { color: '#fff', fontSize: 20 },
  voile: { flex: 1, flexDirection: 'row', backgroundColor: 'rgba(0,0,0,0.55)' },
  panneau: { width: '82%', backgroundColor: C.fond, paddingHorizontal: 12, borderRightWidth: 1, borderRightColor: C.bord },
  panneauTete: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 },
  panneauTitre: { color: C.texte, fontSize: 20, fontWeight: 'bold' },
  nouvelleBtn: { backgroundColor: C.accent, borderRadius: 14, padding: 13, alignItems: 'center', marginBottom: 12 },
  nouvelleTexte: { color: '#fff', fontWeight: 'bold', fontSize: 15 },
  videTexte: { color: C.gris, textAlign: 'center', marginTop: 30 },
  convLigne: {
    flexDirection: 'row', alignItems: 'center', backgroundColor: C.carte, borderRadius: 14,
    borderWidth: 1, borderColor: C.bord, padding: 10, marginBottom: 8,
  },
  convEmoji: { fontSize: 20, marginRight: 10 },
  convTitre: { color: C.texte, fontSize: 15, fontWeight: '600' },
  convDate: { color: C.gris, fontSize: 12, marginTop: 2 },
});
